# PAV changes

## 3.0.0.1
* PAV 3 Beta
* Improved large variant (alignment-truncating) variants
* Complex variant discovery algorithm
* Faster inversion detection with less memory
