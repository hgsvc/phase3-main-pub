# HGSVC3 experiments

This repository documents experiments run for HGSVC3 as well as pipelines and parameters used.
